#include <iostream>
using namespace std; 

unsigned long long int fib(int n){
    if(n==0||n==1){return n;}
    return fib(n-1) + fib(n-2);
}

int main(){

    // Start 
    timespec_get(&ts, TIME_UTC);
    unsigned long long  int start = ts.tv_nsec;

    int n;
    cin>>n;
    
    for(int i=1;i<=n;i++){
        
        cout<<fib(i)<<endl;
    }
    // End 
    timespec_get(&ts, TIME_UTC);
    unsigned long long int end = ts.tv_nsec;
    strftime(buff, sizeof buff, "%D %T", gmtime(&ts.tv_sec));
    
    cout << "Execution time: " << end - start << " nsec" << endl;
    return 0;

}
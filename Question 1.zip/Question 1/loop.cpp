#include <iostream>
#include <time.h>
using namespace std; 

int main(){
    struct timespec ts;
    char buff[100];

    // Start 
    timespec_get(&ts, TIME_UTC);
    unsigned long long  int start = ts.tv_nsec;
    
    int n=100;

    float a=0;
    float b=1;
    cout<<a<<endl;
    cout<<b<<endl;
    
    float temp;
    for(int i=2;i<=n;i++){
        cout<<a+b<<endl;
        temp=a;
        a=b;
        b+=temp;
    }
    // End 
    timespec_get(&ts, TIME_UTC);
    unsigned long long int end = ts.tv_nsec;
    strftime(buff, sizeof buff, "%D %T", gmtime(&ts.tv_sec));
    
    cout << "Time Elapsed: " << end - start << " nsec" << endl;
 
    return 0;
}
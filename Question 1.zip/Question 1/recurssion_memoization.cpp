#include <iostream>
#include <time.h>
using namespace std; 
float arr[100];

float fib(int n){
    if(n==0||n==1){return n;}
    else if(arr[n]!=-1){
        return arr[n];
    }
    else{
        float answer=fib(n-1)+fib(n-2);
        arr[n]=answer;
        return arr[n];
    }
}
int main(){
    struct timespec ts;
    char buff[100];

    // Start 
    timespec_get(&ts, TIME_UTC);
    unsigned long long  int start = ts.tv_nsec;
    
    int n=100;
    for(int i=0;i<=n;i++){
        arr[i]=-1;
    }
    for(int i=0;i<=n;i++){
        
        cout<<fib(i)<<endl;
    }
    // End 
    timespec_get(&ts, TIME_UTC);
    unsigned long long int end = ts.tv_nsec;
    strftime(buff, sizeof buff, "%D %T", gmtime(&ts.tv_sec));
    
    cout << "Execution time: " << end - start << " nsec" << endl;
 
    return 0;
}
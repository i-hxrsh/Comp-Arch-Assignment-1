#include <iostream>
#include <time.h>
using namespace std;

float arr[1000];

float fib(int n)
{
    if (n==1||n==0){
        return n;
    }
    else if (arr[n]!=0)
    {
        return arr[n];
    }
    else
    {
        int i=1;
        float a=0;
        float b=1;
        while (i<=n)
        {
            while (arr[i]!=0)
            {
                a=arr[i-1];
                b=arr[i];
                i++;
            }
            float temp=b;
            b+=a;
            a=temp;
            arr[i] = b;
            i++;
        }
        return b;
    }
}
int main(){
    struct timespec ts;
    char buff[100];

    // Start 
    timespec_get(&ts, TIME_UTC);
    unsigned long long  int start = ts.tv_nsec;
    
    int n=100;
    arr[0] = 0;
    arr[1] = 1;
    
    for (int i=0; i<=n; i++)
    {
        cout<<fib(i)<<endl;
    }

    // End 
    timespec_get(&ts, TIME_UTC);
    unsigned long long int end = ts.tv_nsec;
    strftime(buff, sizeof buff, "%D %T", gmtime(&ts.tv_sec));
    
    cout << "Execution time: " << end - start << " nsec" << endl;
 
    return 0;
}
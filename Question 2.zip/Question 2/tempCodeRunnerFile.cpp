// End 
    // timespec_get(&ts, TIME_UTC);
    // unsigned long long int end = ts.tv_nsec;
    // strftime(buff, sizeof buff, "%D %T", gmtime(&ts.tv_sec));
    
    // cout << "Execution time: " << end - start << " nsec" << endl;
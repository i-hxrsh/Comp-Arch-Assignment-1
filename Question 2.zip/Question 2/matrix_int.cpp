#include <iostream>
#include <bits/stdc++.h>
#include <time.h>
using namespace std;


int main(){
    
    
    int n=512;
    unsigned int A[n][n];
    unsigned int B[n][n];
    long double C[n][n];
    for(int i=0; i<n; i++){
        for(int j=0;j<n;j++){
            A[i][j]=rand();
        }
    }
    for(int i=0; i<n; i++){
        for(int j=0;j<n;j++){
            B[i][j]=rand();
        }
    }

    struct timespec ts;
    char buff[100];

    // Start 
    timespec_get(&ts, TIME_UTC);
    unsigned long long  int start = ts.tv_nsec;
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            long double ans=0;
            for(int k=0;k<n;k++){
                ans+=A[i][k]*B[k][j];
            }
            C[i][j]=ans;
        }
    }
    cout<<n<<endl;
    for(int i=0; i<n; i++){
        for(int j=0;j<n-1;j++){
            cout<<C[i][j]<<' ';
        }
        cout<<C[i][n-1]<<endl;
    }

    // End 
    timespec_get(&ts, TIME_UTC);
    unsigned long long int end = ts.tv_nsec;
    strftime(buff, sizeof buff, "%D %T", gmtime(&ts.tv_sec));
    
    // cout << "Execution time: " << end - start << " nsec" << endl;
 
    return 0;
}
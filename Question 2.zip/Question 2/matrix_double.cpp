#include <iostream>
#include <bits/stdc++.h>
#include <time.h>
using namespace std;


int main(){
    
    
    int n=512;
    double A[n][n];
    double B[n][n];
    double C[n][n];
    for(int i=0; i<n; i++){
        for(int j=0;j<n;j++){
            A[i][j]=(double(rand())/double((RAND_MAX)) * 10000);
        }
    }
    for(int i=0; i<n; i++){
        for(int j=0;j<n;j++){
            B[i][j]=(double(rand())/double((RAND_MAX)) * 10000);
        }
    }

    struct timespec ts;
    char buff[100];

    // Start 
    timespec_get(&ts, TIME_UTC);
    unsigned long long  int start = ts.tv_nsec;

    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            double ans=0;
            for(int k=0;k<n;k++){
                ans+=A[i][k]*B[k][j];
            }
            C[i][j]=ans;
        }
    }
    for(int i=0; i<n; i++){
        for(int j=0;j<n-1;j++){
            cout<<C[i][j]<<' ';
        }
        cout<<C[i][n-1]<<endl;
    }

    // End 
    timespec_get(&ts, TIME_UTC);
    unsigned long long int end = ts.tv_nsec;
    strftime(buff, sizeof buff, "%D %T", gmtime(&ts.tv_sec));
    
    cout << "Execution time: " << end - start << " nsec" << endl;
 
    return 0;
}
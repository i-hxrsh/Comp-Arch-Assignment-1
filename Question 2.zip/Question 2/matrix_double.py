import random
import timeit

n=int(input())
A=[]
B=[]
C=[]

for i in range(n):
    temp=[]
    for j in range(n):
        temp.append(random.uniform(0.0, 9999.99))
    A.append(temp)

for i in range(n):
    temp=[]
    for j in range(n):
        temp.append(random.uniform(0.0, 9999.99))
    B.append(temp)

start = timeit.default_timer()

for i in range(n):
    temp=[]
    for j in range(n):
        count=0
        for k in range(n):
            count+=A[i][k]*B[k][j]
        temp.append(count)
    C.append(temp)


for i in range(n):
    for j in range(n-1):
        print(C[i][j], end=" ")
    print(C[i][n-1])
stop = timeit.default_timer()
print('')
print('Time: ', stop - start)